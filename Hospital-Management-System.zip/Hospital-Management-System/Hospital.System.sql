create database HospitalManagement;
create table patient(
name varchar(50),
age int, 
gender varchar(10),
contact mediumtext,
issue varchar(20),
sissue varchar(100),
patientid varchar(10),
pswd varchar(10),
adate date);
use HospitalManagement;
create table doctor(
name varchar(50),
email varchar(50),
gender varchar(10), 
specin varchar(50),
specifics varchar(100),
docid varchar(10), 
pswd varchar(10));
select * from doctor;
select * from patient;
